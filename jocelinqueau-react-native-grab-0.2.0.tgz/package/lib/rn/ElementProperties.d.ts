/**
 * Ported from React Native's element inspector.
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the LICENSE
 * file in the root directory of the React Native source tree:
 * packages/react-native/src/private/devsupport/devmenu/elementinspector/
 *   {ElementProperties,BoxInspector,StyleInspector}.js
 *
 * Changes: ported to TypeScript, merged into one file, and the source
 * location (`file:line`) added — React Native shows nothing of the sort.
 */
import React from 'react';
import type { GrabSelection } from '../inspector/types';
interface ElementPropertiesProps {
    selection: GrabSelection;
    onSelectIndex: (index: number) => void;
}
export declare function ElementProperties({ selection, onSelectIndex }: ElementPropertiesProps): React.JSX.Element;
export {};
//# sourceMappingURL=ElementProperties.d.ts.map