/**
 * Ported from React Native's element inspector.
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the LICENSE
 * file in the root directory of the React Native source tree:
 * packages/react-native/src/private/devsupport/devmenu/elementinspector/
 *   InspectorPanel.js
 *
 * Changes: ported to TypeScript; the Inspect/Touchables toggles are replaced
 * by what React Native does not offer — copying the selection for a coding
 * agent.
 */
import React from 'react';
import type { GrabSelection } from '../inspector/types';
interface InspectorPanelProps {
    selection: GrabSelection | null;
    onSelectIndex: (index: number) => void;
    onClose: () => void;
    /** Where the selection goes. Absent: the clipboard, exactly as before. */
    onGrab?: (text: string, selection: GrabSelection) => void | Promise<void>;
    grabLabel?: string;
    grabDoneLabel?: string;
}
export declare function InspectorPanel({ selection, onSelectIndex, onClose, onGrab, grabLabel, grabDoneLabel, }: InspectorPanelProps): React.JSX.Element;
export {};
//# sourceMappingURL=InspectorPanel.d.ts.map