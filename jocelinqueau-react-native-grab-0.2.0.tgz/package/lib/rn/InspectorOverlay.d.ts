/**
 * Ported from React Native's element inspector.
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the LICENSE
 * file in the root directory of the React Native source tree:
 * packages/react-native/src/private/devsupport/devmenu/elementinspector/
 *   InspectorOverlay.js
 *
 * Changes: ported to TypeScript, and a move reports through `onMovePoint` so
 * a drag can be previewed without paying for a full selection each frame.
 */
import React from 'react';
import type { GrabSelection, InspectorFrame } from '../inspector/types';
interface InspectorOverlayProps {
    selection: GrabSelection | null;
    hoveredFrame: InspectorFrame | null;
    onTouchPoint: (x: number, y: number) => void;
    onMovePoint: (x: number, y: number) => void;
}
export declare function InspectorOverlay({ selection, hoveredFrame, onTouchPoint, onMovePoint, }: InspectorOverlayProps): React.JSX.Element;
export {};
//# sourceMappingURL=InspectorOverlay.d.ts.map