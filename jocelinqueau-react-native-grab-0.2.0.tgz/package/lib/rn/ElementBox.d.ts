/**
 * Ported from React Native's element inspector.
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the LICENSE
 * file in the root directory of the React Native source tree:
 * packages/react-native/src/private/devsupport/devmenu/elementinspector/
 *   {ElementBox,BorderBox}.js
 *
 * Changes: ported to TypeScript, merged into one file.
 */
import React from 'react';
import type { InspectorFrame } from '../inspector/types';
interface ElementBoxProps {
    frame: InspectorFrame;
    style?: unknown;
}
/** The blue/green/orange highlight: content, padding and margin. */
export declare function ElementBox({ frame, style }: ElementBoxProps): React.JSX.Element;
export {};
//# sourceMappingURL=ElementBox.d.ts.map