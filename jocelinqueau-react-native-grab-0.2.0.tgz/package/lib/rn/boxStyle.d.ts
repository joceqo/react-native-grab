export interface BoxEdges {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
type Style = Record<string, unknown>;
/**
 * Resolve a style property into its component parts.
 *
 *   resolveBoxStyle('margin', {margin: 5, marginBottom: 10})
 *   → {top: 5, right: 5, bottom: 10, left: 5}
 *
 * Returns null when no part of the property is set.
 */
export declare function resolveBoxStyle(prefix: string, style: Style): BoxEdges | null;
export {};
//# sourceMappingURL=boxStyle.d.ts.map