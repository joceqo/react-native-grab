type Handler = () => void;
/**
 * Add an entry to the developer menu (⌘D on the iOS simulator, ⌘M on Android,
 * shake on device). Returns a function that detaches the handler — the menu
 * entry itself stays, since the platform offers no way to remove it.
 */
export declare function addDevMenuItem(title: string, handler: Handler): () => void;
export {};
//# sourceMappingURL=devMenu.d.ts.map