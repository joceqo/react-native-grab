import type { GrabSelection } from './inspector/types';
export declare function serializeForLLM(selection: GrabSelection): string;
//# sourceMappingURL=serialize.d.ts.map