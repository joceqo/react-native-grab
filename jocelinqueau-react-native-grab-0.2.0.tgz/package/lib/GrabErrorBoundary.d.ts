import React, { Component, type ReactNode } from 'react';
interface Props {
    children: ReactNode;
    fallback: ReactNode;
}
interface State {
    hasError: boolean;
}
export declare class GrabErrorBoundary extends Component<Props, State> {
    state: State;
    static getDerivedStateFromError(): State;
    componentDidCatch(error: unknown): void;
    render(): React.ReactNode;
}
export {};
//# sourceMappingURL=GrabErrorBoundary.d.ts.map