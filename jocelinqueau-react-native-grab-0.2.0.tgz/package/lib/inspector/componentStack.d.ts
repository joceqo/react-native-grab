import type { StackFrame } from './types';
/** Turn React's `componentStack` string into frames, innermost first. */
export declare function parseComponentStack(componentStack: string | null | undefined): StackFrame[];
/** Keep the last two path segments — enough to recognise a file, short enough to read. */
export declare function shortPath(fileName: string): string;
/**
 * `short` trims the path for on-screen display. Leave it off when the text is
 * headed for a coding agent — it can open a full path.
 */
export declare function formatStackFrame(frame: StackFrame, options?: {
    short?: boolean;
}): string;
/**
 * A frame written by the app rather than by a dependency. Everything useful to
 * a developer — and to a coding agent — lives in these.
 */
export declare function isAppFrame(frame: StackFrame): boolean;
export declare function appFrames(stack: StackFrame[]): StackFrame[];
/**
 * Locate the stack frame describing `hierarchy[index]`.
 *
 * App code wins over dependencies: pointing at
 * `node_modules/react-native/.../View.js` is technically right and practically
 * useless. Within app frames, a name match wins over position — the hierarchy
 * runs root → leaf while the stack runs leaf → root, so the positional guess
 * is mirrored, and the two lists do not always hold the same host components.
 */
export declare function findSourceFrame(stack: StackFrame[], hierarchy: string[], index: number): StackFrame | null;
//# sourceMappingURL=componentStack.d.ts.map