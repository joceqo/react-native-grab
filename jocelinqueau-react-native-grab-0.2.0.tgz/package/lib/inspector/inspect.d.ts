import type { GrabSelection } from './types';
/**
 * Ask React what sits at a point on screen.
 *
 * `inspectedView` must be the host instance wrapping your app: it scopes the
 * hit test, so the inspector's own overlays are never selected — and Fabric
 * dereferences it without a null check, so there is no meaningful default.
 */
export declare function inspectAtPoint(x: number, y: number, inspectedView: unknown): Promise<GrabSelection | null>;
/**
 * Move the selection to another level of the same hierarchy — one step towards
 * the root, or back down towards the touched element.
 */
export declare function selectHierarchyIndex(selection: GrabSelection, index: number): Promise<GrabSelection | null>;
export { isInspectorAvailable } from './getInspectorDataForViewAtPoint';
export { symbolicateStack } from './symbolicate';
//# sourceMappingURL=inspect.d.ts.map