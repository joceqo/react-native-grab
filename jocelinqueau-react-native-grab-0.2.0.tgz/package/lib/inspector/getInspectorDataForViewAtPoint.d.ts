/**
 * Adapted from React Native's built-in element inspector.
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the LICENSE
 * file in the root directory of the React Native source tree:
 * packages/react-native/src/private/devsupport/devmenu/elementinspector/
 *   getInspectorDataForViewAtPoint.js
 *
 * Changes from the original:
 *  - ported to TypeScript;
 *  - no `invariant`: returns `false` instead of throwing when the React
 *    DevTools hook or a renderer is missing, so importing this module can
 *    never crash an app;
 *  - renderers are resolved lazily on each call instead of at import time,
 *    so the module may be imported before React has injected itself.
 */
export interface InspectorFrame {
    top: number;
    left: number;
    width: number;
    height: number;
}
export type MeasureOnSuccessCallback = (x: number, y: number, width: number, height: number, pageX: number, pageY: number) => void;
export type FindNodeHandle = (componentOrHandle: unknown) => number | null;
export interface RawHierarchyItem {
    name?: string | null;
    getInspectorData: (findNodeHandle: FindNodeHandle) => {
        measure: (callback: MeasureOnSuccessCallback) => void;
        props: Record<string, unknown>;
    };
}
/** What React hands back for a point on screen. */
export interface RawInspectorData {
    hierarchy: RawHierarchyItem[];
    selectedIndex?: number | null;
    props: Record<string, unknown>;
    componentStack: string;
    frame: InspectorFrame;
    pointerY?: number;
    touchedViewTag?: number;
    closestInstance?: unknown;
}
/**
 * True when React exposes the inspector on at least one renderer. This is the
 * case in any development build — it does *not* require the React DevTools
 * backend to be connected.
 */
export declare function isInspectorAvailable(): boolean;
/**
 * Ask every renderer what sits at (locationX, locationY).
 *
 * `inspectedView` scopes the search to a subtree — pass the host instance
 * wrapping your app so the inspector's own overlays are never selected.
 *
 * Returns `false` when no renderer could be queried at all. The callback may
 * be invoked asynchronously (it is, on Fabric).
 */
export declare function getInspectorDataForViewAtPoint(inspectedView: unknown, locationX: number, locationY: number, callback: (viewData: RawInspectorData) => boolean): boolean;
//# sourceMappingURL=getInspectorDataForViewAtPoint.d.ts.map