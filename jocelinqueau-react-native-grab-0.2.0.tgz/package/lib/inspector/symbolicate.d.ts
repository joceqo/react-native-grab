import type { StackFrame } from './types';
/**
 * Replace bundle offsets with real `file:line:column` locations.
 *
 * Frames that are not bundle offsets are left untouched, and any failure —
 * no Metro, offline, malformed answer — returns the frames unchanged.
 */
export declare function symbolicateStack(frames: StackFrame[]): Promise<StackFrame[]>;
//# sourceMappingURL=symbolicate.d.ts.map