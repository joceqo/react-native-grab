import { type MutableRefObject } from 'react';
import type { GrabSelection, InspectorFrame } from '../inspector/types';
export interface Inspector {
    active: boolean;
    selection: GrabSelection | null;
    hoveredFrame: InspectorFrame | null;
    activate: () => void;
    deactivate: () => void;
    toggle: () => void;
    /** Select whatever sits under a point, in screen coordinates. */
    select: (x: number, y: number) => void;
    /** Preview what sits under a point without committing to it. */
    hover: (x: number, y: number) => void;
    selectIndex: (index: number) => void;
    selectParent: () => void;
    selectChild: () => void;
    clearSelection: () => void;
}
export declare function useInspector(inspectedViewRef: MutableRefObject<unknown>): Inspector;
//# sourceMappingURL=useInspector.d.ts.map