export { useInspector } from './useInspector';
export type { Inspector } from './useInspector';
//# sourceMappingURL=index.d.ts.map