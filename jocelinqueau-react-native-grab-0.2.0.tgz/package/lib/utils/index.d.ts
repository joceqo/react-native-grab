export { copyToClipboard } from './clipboard';
//# sourceMappingURL=index.d.ts.map