import React from 'react';
interface GrabTriggerProps {
    isActive: boolean;
    onToggle: () => void;
}
export declare function GrabTrigger({ isActive, onToggle }: GrabTriggerProps): React.JSX.Element;
export {};
//# sourceMappingURL=GrabTrigger.d.ts.map