import React, { type ReactNode } from 'react';
import type { GrabSelection } from './inspector/types';
export interface GrabProps {
    /** Enable the inspector. Pass `__DEV__` so it drops out of production. */
    enabled?: boolean;
    /**
     * How to enter inspection mode.
     *  - `devMenu` (default): an entry in the developer menu (⌘D / ⌘M / shake).
     *  - `button`: a floating button, always on screen.
     *  - `both`: either.
     */
    trigger?: 'devMenu' | 'button' | 'both';
    /** Label of the developer-menu entry. */
    devMenuLabel?: string;
    /**
     * What to do with the selection. Defaults to copying it to the clipboard.
     *
     * The clipboard is a fine destination when the agent runs on the same machine
     * as the app. It is a dead end when it does not — a phone inspecting itself, a
     * device on a desk, an agent living behind an API. Handing the serialized block
     * over lets the app decide where it goes: POST it, write it to a file, drop it
     * into a chat that already talks to the agent.
     *
     * Receives both the paste-ready text and the raw selection, so a caller
     * building its own payload does not have to serialize twice.
     */
    onGrab?: (text: string, selection: GrabSelection) => void | Promise<void>;
    /** Label of the panel's action button. Set it when `onGrab` changes its meaning. */
    grabLabel?: string;
    /** Confirmation shown for two seconds once the action resolves. */
    grabDoneLabel?: string;
    children: ReactNode;
}
export declare function Grab({ enabled, trigger, devMenuLabel, onGrab, grabLabel, grabDoneLabel, children, }: GrabProps): React.JSX.Element;
//# sourceMappingURL=Grab.d.ts.map