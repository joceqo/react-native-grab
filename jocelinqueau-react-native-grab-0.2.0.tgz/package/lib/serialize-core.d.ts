import type { GrabSelection } from './inspector/types';
export interface SerializeOptions {
    /**
     * Optional flatten function (typically `StyleSheet.flatten` from React
     * Native). When provided, it normalizes array-of-style props before
     * stringifying. When absent, values go straight to `JSON.stringify`.
     */
    flattenStyle?: (style: unknown) => unknown;
}
/** Props worth showing: no children, no nullish, no React or internal plumbing. */
export declare function visibleProps(props: Record<string, unknown>): Array<[string, unknown]>;
/** Render one selection as a block meant to be pasted into a coding agent. */
export declare function serializeForLLMCore(selection: GrabSelection, opts?: SerializeOptions): string;
//# sourceMappingURL=serialize-core.d.ts.map